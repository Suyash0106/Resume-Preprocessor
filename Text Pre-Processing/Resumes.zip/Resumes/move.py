import shutil

prev = "G:/SEMESTER 2/FIT5196/Assignment/Assignment 1/Task 2/Resumes/resume_(1)"
new = "G:/SEMESTER 2/FIT5196/Assignment/Assignment 1/Task 2/Resumes/data/resume_(1)"
shutil.move(prev,new)
